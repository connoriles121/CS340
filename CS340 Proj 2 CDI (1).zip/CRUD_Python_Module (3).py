 # Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 
class AnimalShelter(object): 
    #CRUD operations for Animal collection 

    def __init__(self, username, pasword): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        #
        # You must edit the password below for your environment. 
        #
        # Connection Variables 
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        
        # Initialize Connection 

        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method 

    # Complete this create method to implement the C in CRUD. 

    def create(self, data):
        if data is not None:
            try:
                #use insert_one to add dictionary
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Error Inserting document: {e}")
                return False
        else:
            raise Exception("Nothing to save, data parameter empty")

    # Create method to implement the R in CRUD.
    def read(self, query):
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"Error querying documents: {e}")
            return[]
    #Update     
    def update(self, query, data):
        
        if query is not None:
            try:
                result = self.collection.update_many(query, {"$set": data})
                return result.modified_count
            except Exception as e:
                print(f"Error updating documents: {e}")
                return 0
        else:
            print("Update query is empty.")
            return 0
    #Delete 
    def delete(self, query):
        if query is not None:
            try: 
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error deleting documents: {e}")
                return 0
        else:
            print("Delete query is empty.")
            return 0


